<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo e($title); ?></h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><?php echo e($title); ?></li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">

                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($cardTitle); ?></h5>

                            <!-- Table with stripped rows -->
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Kode Kelas</th>
                                        <th scope="col">Keterangan Kelas</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr scope="row">
                                        <?php
                                            $no = 1;
                                            foreach($materi as $key => $row) {
                                        ?>
                                        <td><?= $no++ ?></td>
                                        <td><?= $row->kode_kelas ?></td>
                                        <td><?= $row->ket_kelas ?></td>
                                        <td>
                                            <a style="text-decoration-style: none"
                                                href="<?php echo e(route('detail', ['kode_kel' => encrypt($row->kode_kelas)])); ?>"
                                                class="btn btn-primary">
                                                <i class="bi bi-info-square"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                            <!-- End Table with stripped rows -->
                        </div>
                    </div>

                </div>
            </div>
        </section>

    </main><!-- End #main -->

    <!-- Kumpulan Modal -->
    <!-- Modal Tambah Materi -->
    <div class="modal fade" id="addMateri" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel"><?php echo e($modalTitle['materi']); ?></h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('tambahMateri')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Pilih Kelas</label>
                            <select class="form-select" id="inputGroupSelect01" name="pilKelas" required>
                                <option selected disabled value="">Pilih Kelas...</option>
                                <option value="1">Kelas Satu</option>
                                <option value="2">Kelas Dua</option>
                                <option value="3">DST</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Pilih Materi Yang Akan Di
                                Upload</label>
                            <div>
                                <button type="button" class="btn btn-warning" onclick="kata()"><i
                                        class="bi bi-fonts"></i></button>
                                <button type="button" class="btn btn-secondary" onclick="gambar()"><i
                                        class="bi bi-image"></i></button>
                                <button type="button" class="btn btn-primary" onclick="video()"><i
                                        class="bi bi-play-btn"></i></button>
                            </div>
                        </div>
                        <div id="formText">
                            <!-- Form dinamis akan ditambahkan di sini -->
                        </div>
                        <div id="formGambar">
                            <!-- Form dinamis akan ditambahkan di sini -->
                        </div>
                        <div id="formVideo">
                            <!-- Form dinamis akan ditambahkan di sini -->
                        </div>
                </div>
                <div class="modal-footer">
                    
                    <button type="submit" class="btn btn-success">Simpan Data</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.mainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\GitHub\LARAVEL\Project_hallo_ivy_Web_laravel\resources\views/content/materi.blade.php ENDPATH**/ ?>