<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Dashboard</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->
        
        

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\GitHub\LARAVEL\Project_hallo_ivy_Web_laravel\resources\views/content/dashboard.blade.php ENDPATH**/ ?>