 <!-- ======= Sidebar ======= -->
 <aside id="sidebar" class="sidebar">

     <ul class="sidebar-nav" id="sidebar-nav">

         

         

         <li class="nav-item">
             <a class="nav-link <?php echo e(request()->routeIs('materi') ? '' : 'collapsed'); ?>" href="<?php echo e(route('materi')); ?>">
                 <i class="bi bi-journal-text"></i>
                 
                 <span>Materi</span>
             </a>
         </li><!-- End Profile Page Nav -->

         <li class="nav-item">
             <a class="nav-link <?php echo e(request()->routeIs('tugas') ? '' : 'collapsed'); ?>" href="<?php echo e(route('tugas')); ?>">
                 <i class="bi bi-journal-check"></i>
                 <span>Tugas Rumah</span>
             </a>
         </li><!-- End F.A.Q Page Nav -->

         

     </ul>

 </aside><!-- End Sidebar-->
<?php /**PATH C:\wamp64\www\GitHub\LARAVEL\Project_hallo_ivy_Web_laravel\resources\views/layout/aside.blade.php ENDPATH**/ ?>