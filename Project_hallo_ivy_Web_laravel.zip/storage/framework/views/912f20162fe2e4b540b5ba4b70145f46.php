<!-- ======= Footer ======= -->
<footer id="footer" class="footer fixed-bottom bg-light mt-5">
    <div class="copyright">
        &copy; Copyright <strong><span><a href="https://akb.ac.id/aknpsf/" style="text-decoration-line: none; text-decoration-color: none;">By AKN PUTRA SANG FAJAR
                    BLITAR</a></span></strong>. All Rights Reserved
    </div>
    
</footer><!-- End Footer -->
<?php /**PATH C:\wamp64\www\GitHub\LARAVEL\Project_hallo_ivy_Web_laravel\resources\views/layout/footer.blade.php ENDPATH**/ ?>